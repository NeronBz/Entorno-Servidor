<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h1>CREAR RESERVA</h1>
    <form action="<?php echo e(route('rutaInsertar')); ?>" method="POST">
        <?php echo csrf_field(); ?>
        <label for="viaje">Viaje</label>
        <select name="viaje" id="viaje">
            <?php $__currentLoopData = $viajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(old('viaje') != null and old('viaje') == $v->id): ?>
                    <option value="<?php echo e($v->id); ?>" selected="selected"><?php echo e($v->tituloV); ?></option>
                <?php else: ?>
                    <option value="<?php echo e($v->id); ?>"><?php echo e($v->tituloV); ?></option>
                <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        <?php $__errorArgs = ['viaje'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div>
                Rellena Viaje
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="fecha">Fecha</label>
        <?php if(old('fecha') != null): ?>
            <input type="date" name="fecha" value="<?php echo e(old('fecha')); ?>">
        <?php else: ?>
            <input type="date" name="fecha" value="<?php echo e(date('Y-m-d')); ?>">
        <?php endif; ?>
        <?php $__errorArgs = ['fecha'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div>
                Rellena Fecha
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <label for="nombre">Cliente</label>
        <input type="text" name="nombre">
        <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div>
                Rellena Nombre
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
        <label for="nPersonas">Nº Personas</label>
        <input type="number" name="nPersonas">
        <?php $__errorArgs = ['nPersonas'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div>
                Rellena Nº de Personas
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>

        <button type="submit">Crear</button>
        <a href="<?php echo e(route('rutaVer')); ?>">Cancelar</a>
    </form>
    <div style="color:red">
        <?php if(session('mensaje') != null): ?>
            <?php echo e(session('mensaje')); ?>

        <?php endif; ?>
    </div>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\DWES\Entorno-Servidor\ExamenViajes\resources\views/crearR.blade.php ENDPATH**/ ?>