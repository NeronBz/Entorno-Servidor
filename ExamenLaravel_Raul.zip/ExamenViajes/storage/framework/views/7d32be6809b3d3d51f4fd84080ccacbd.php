<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>

<body>
    <h1>VIAJES</h1>
    <a href="<?php echo e(route('rutaCrear')); ?>">+Nuevo</a>
    <table>
        <tr>
            <th>Id</th>
            <th>Titulo-del-Viaje</th>
            <th>Destino</th>
            <th>Nº-noches</th>
            <th>Nº-de-Plazas</th>
            <th>Precio</th>
        </tr>
        <?php $__currentLoopData = $viajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $v): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($v->id); ?></td>
                <td><?php echo e($v->tituloV); ?></td>
                <td><?php echo e($v->destino); ?></td>
                <td><?php echo e($v->nNoches); ?></td>
                <td><?php echo e($v->nPlazas); ?></td>
                <td><?php echo e($v->pPersona); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </table>
</body>

</html>
<?php /**PATH C:\xampp\htdocs\DWES\Entorno-Servidor\ExamenViajes\resources\views/verV.blade.php ENDPATH**/ ?>